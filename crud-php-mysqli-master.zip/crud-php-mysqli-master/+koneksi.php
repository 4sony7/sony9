<?php 
// koneksi dengan mysqli

// isi nama host, username mysql, password mysql, dan nama database anda
$con = mysqli_connect("localhost", "root", "12", "crud2");


/*
Code by YukCoding Tutor
www.yukcoding.id
*/
?>
