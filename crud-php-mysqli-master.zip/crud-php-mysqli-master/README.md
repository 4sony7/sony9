# crud-php-mysqli
Source code CRUD (Create, Read, Update, Delete) sederhana dengan PHP ekstensi mysqli dan database MariaDB.

Database sama dengan crud sebelumnya yang ini https://yukcoding.id/source-code-crud-php-mysql/ 
